-- BETA VERSION " SCRIPT IS UPDATING " [SMT SCRIPT]

Config = {}

Config.Locale = 'cs'
Config.Notify = 'ox_lib'


Config.GarageLocations = {
    {entry = vector3(210.8261, -1467.8650, 29.1726), exit = vector3(210.8261, -1467.8650, 28.1726), interior = vector3(207.3230, -999.0406, -99.0000)},
    
    -- MESTO
    {entry = vector3(487.1983, -1470.4802, 28.5295), exit = vector3(487.1983, -1470.4802, 28.5295), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-1329.8099, -1150.3158, 4.3801), exit = vector3(-1329.8099, -1150.3158, 4.3801), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-1490.2510, -901.9683, 10.0236), exit = vector3(-1490.2510, -901.9683, 10.0236), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-1276.2505, -1365.2296, 4.3040), exit = vector3(-1276.2505, -1365.2296, 4.3040), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-1249.7007, -1426.1184, 4.3229), exit = vector3(-1249.7007, -1426.1184, 4.3229), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(507.7826, -1492.5536, 29.2880), exit = vector3(507.7826, -1492.5536, 29.2880), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-15.0770, -1558.2788, 29.5289), exit = vector3(-15.0770, -1558.2788, 29.5289), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(270.9364, -1761.2906, 28.9353), exit = vector3(270.9364, -1761.2906, 28.9353), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(401.2865, -1826.6819, 28.4062), exit = vector3(401.2865, -1826.6819, 28.4062), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(268.6926, -1962.6455, 23.0930), exit = vector3(268.6926, -1962.6455, 23.0930), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(136.5868, -1503.5483, 29.1416), exit = vector3(136.5868, -1503.5483, 29.1416), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-687.1263, -161.8223, 37.8213), exit = vector3(-687.1263, -161.8223, 37.8213), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(206.1943, -1472.5760, 29.1555), exit = vector3(206.1943, -1472.5760, 29.1555), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(206.1943, -1472.5760, 29.1555), exit = vector3(206.1943, -1472.5760, 29.1555), interior = vector3(207.3230, -999.0406, -99.0000)},

    -- PALETO
    {entry = vector3(-215.2682, 6250.3770, 31.4911), exit = vector3(-215.2682, 6250.3770, 31.4911), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(5.0046, 6465.9575, 31.42534), exit = vector3(5.0046, 6465.9575, 31.4253), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-281.0297, 6168.6138, 31.5018), exit = vector3(-281.0297, 6168.6138, 31.5018), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(81.3533, 6643.9600, 31.9290), exit = vector3(81.3533, 6643.9600, 31.9290), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-161.8411, 6189.3921, 31.4349), exit = vector3(-161.8411, 6189.3921, 31.4349), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-246.6641, 6068.5176, 32.3446), exit = vector3(-246.6641, 6068.5176, 32.3446), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-428.2704, 6161.8823, 31.4782), exit = vector3(-428.2704, 6161.8823, 31.4782), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-354.2417, 6066.1274, 31.4986), exit = vector3(-354.2417, 6066.1274, 31.4986), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(-111.9723, 6481.0288, 31.4684), exit = vector3(-111.9723, 6481.0288, 31.4684), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(111.7075, 6370.8813, 31.3758), exit = vector3(111.7075, 6370.8813, 31.3758), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(146.9571, 6366.6309, 31.5292), exit = vector3(146.9571, 6366.6309, 31.5292), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(2.6592, 6308.9316, 31.2258), exit = vector3(2.6592, 6308.9316, 31.2258), interior = vector3(207.3230, -999.0406, -99.0000)},

    -- SANDY
    {entry = vector3(2.6592, 6308.9316, 31.2258), exit = vector3(2.6592, 6308.9316, 31.2258), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(2.6592, 6308.9316, 31.2258), exit = vector3(2.6592, 6308.9316, 31.2258), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(2.6592, 6308.9316, 31.2258), exit = vector3(2.6592, 6308.9316, 31.2258), interior = vector3(207.3230, -999.0406, -99.0000)},
    {entry = vector3(2.6592, 6308.9316, 31.2258), exit = vector3(2.6592, 6308.9316, 31.2258), interior = vector3(207.3230, -999.0406, -99.0000)},
}
 
Config.LootSpots = {
    vector3(189.8219, -994.8305, -99.5715),
    vector3(190.3307, -1002.2761, -99.4625),
    vector3(207.2489, -1004.4661, -99.8985),
    vector3(206.7424, -996.0370, -99.9406),
}

Config.LootItems = {
    {item = "money", chance = 100, minAmount = 500, maxAmount = 4500},
    {item = "lockpick", chance = 30, minAmount = 1, maxAmount = 5},
    {item = "box-ammo-9", chance = 15, minAmount = 1, maxAmount = 5},
    {item = "bracelet", chance = 20, minAmount = 1, maxAmount = 6},
    {item = "ring", chance = 20, minAmount = 1, maxAmount = 4},
    {item = "watch", chance = 10, minAmount = 1, maxAmount = 4},
    {item = "weapon_pistol", chance = 1, minAmount = 1, maxAmount = 1},
    {item = "weapon_poolcue", chance = 10, minAmount = 1, maxAmount = 1},
    {item = "weapon_knuckle", chance = 10, minAmount = 1, maxAmount = 1},
    {item = "boostingtablet", chance = 5, minAmount = 1, maxAmount = 1},
    {item = "weapon_crowbar", chance = 5, minAmount = 1, maxAmount = 1},
    {item = "burger", chance = 80, minAmount = 1, maxAmount = 5},
    {item = "water", chance = 80, minAmount = 1, maxAmount = 5},
}

Config.RequiredItem = "lockpick"

Config.Locales = { -- en
    useLockpickLabel = "Use Lockpick", 
    lootSpotLabel = "Loot",
    lootingSpots = "Looting Spot ...", 
    lootSpotAlreadyLooted = "This spot is looted.",
    lootSpotFailed = "Loot Failed.",
    leaveGarage = "Leave Garage",
    garageEntered = "Garage Entered",
    garageExited = "You exit garage",
    missingLockpick = "Missing Item LockPick to robbery",
    lockpickFailed = "Try Agin.",
    lootFound = "Get loot",
    lootAmount = "Find %d x %s.",

    notify = { -- en
        garageEntered = 'You have entered to garage.',  -- You can change
        garageExited = 'You have exited the garage.',  -- You can change
        lootSpotFailed = 'Failed to loot the spot.',  -- You can change
        lootSpotAlreadyLooted = 'This spot has already been looted.',  -- You can change
        lockpickFailed = 'Lockpicking failed. Try again.',  -- You can change
        lockpickSuccess = 'Lockpick successful! Entering garage.',  -- You can change
        missingLockpick = 'You need a lockpick to open the garage.',  -- You can change
        lootFound = 'You find %s of %s!',  -- You can change
        lootAmount = 'Amount: %d, Item: %s',
    },-- not notify down
    lootSpotLabel = 'Loot', -- You can change
    leaveGarage = 'Leave Garage', -- You can change
}

-- @saekoeu
-- You can change locale [replace]. 
-- Version 1.0.1 - Next update create locales/en.lua
                        --            locales/cs.lua
-- # PLEASE YOU HAVE FIND BUG PLEASE REPORT TO SMT DISCORD !
