fx_version 'cerulean'
game 'gta5'
lua54 'yes'

-- Author / Scripts
author "Smt Scripts"
description "Garage Robbery via ox_lib reworked"

shared_script {
    'config.lua',
    '@ox_lib/init.lua'
}

client_scripts {
    'configs/config.lua',
    'client.lua',
    'locales/en.lua', 
    'locales/cs.lua'
}

server_scripts {
    'server.lua',
    'configs/config.lua'
}

depency {
    'ox_lib', -- https://github.com/overextended/ox_lib/releases/latest/download/ox_lib.zip
    'ox_target', -- https://github.com/overextended/ox_target/releases
    'lockpick' -- https://github.com/quasar-scripts/lockpick
    -- https://smt-scripts.gitbook.io/smt-scripts/free-scripts/smt_garagerobbery
}


